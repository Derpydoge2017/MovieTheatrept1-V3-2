package com.example.admin.movietheatrept1v3.utils;

/**
 * Created by Admin on 20-May-17.
 */

public class MovieChild {
}
